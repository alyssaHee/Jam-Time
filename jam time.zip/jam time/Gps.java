import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The gps scene where user solves a puzzle
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gps extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class OutsideScreen.
     * 
     */
    public Gps()
    {    
        super(700, 480, 1); 
        prepare();
        playMusic();
        setPaintOrder(Screen.class, MapPieces.class, GpsBg.class);
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(new GpsBg(), 350, 240);
        addObject(new Bottom1(),283,404);
        addObject(new Top1(),420,408);
        addObject(new Top3(),556,403);
        addObject(new Top2(),140,402);
        addObject(new Bottom3(),624,269);
        addObject(new Bottom2(),72,265);
    }
    
    // Play music
    public void playMusic()
    {
        backgroundMusic = new GreenfootSound("dummy.mp3");
        backgroundMusic.setVolume(65);
        backgroundMusic.playLoop();
    }
    
    // Stop music
    public void stopMusic()
    {
        backgroundMusic.stop();
    }
   
}
