import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A button that takes you to the how to play screen
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HowToButton extends Actor
{
    /**
     * Act - do whatever the HowToButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        clicked();
    }
    
    // If the button is clicked
    public void clicked()
    {
        if(Greenfoot.mouseClicked(this))
        {
            Greenfoot.playSound("click.mp3");
            getWorld().addObject(new Screen(4, "HowToScreen"), 350, 240);
            // Call the stopMusic method from the HomeScreen
            HomeScreen h = (HomeScreen)getWorld();
            h.stopMusic();
        }
    }
}
