import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Shows the invitation to the party
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InviteScreen extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class StoryWorld.
     * 
     */
    public InviteScreen()
    {    
        super(700, 480, 1); 
        prepare();
        
        backgroundMusic = new GreenfootSound("nighttime.mp3");
        playSound();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(new NextButton(),363,420);
    }
    
    // Play music
    public void playSound()
    {
        backgroundMusic.setVolume(70);
        backgroundMusic.playLoop();
    }
    
    // Stop music (to be called once the world is changed)
    public void stopMusic()
    {
         backgroundMusic.stop();
    }
}
