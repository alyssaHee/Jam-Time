import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Street here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Street extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class Street.
     * 
     */
    public Street()
    {    
        super(700, 480, 1); 
        addObject(new Ground(), 350, 386);
        addObject(new Raccoon(), 50, 305);
        addObject(new Text(4), 350, 450);
        backgroundMusic = new GreenfootSound("nighttime.mp3");
        playMusic();
    }
    
    // Play music
    public void playMusic()
    {
        backgroundMusic.setVolume(50);
        backgroundMusic.playLoop();
    }
    
    // Stop music
    public void stopMusic()
    {
        backgroundMusic.stop();
    }
}
