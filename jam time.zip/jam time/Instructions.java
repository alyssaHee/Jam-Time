import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Instructions here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Instructions extends Actor
{
    // Set the image for the instructions
    public Instructions(int type)
    {
        setImage("instruction" + type + ".png");
    }
}
