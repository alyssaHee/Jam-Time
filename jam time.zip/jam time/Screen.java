import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Screen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Screen extends Actor
{
    // The current transparency of the screen
    private int transparency;
    
    // The speed of the fade out
    private int rate;
    
    // Holds on to the nextWorld being set
    private String nextWorld;
    
    // Default constructor for Screen
    public Screen()
    {
        // Initialize variables
        transparency = 0;
        getImage().setTransparency(0);
        rate = 4;
    }
    
    // Overloading constructor for Screen
    public Screen(int speed, String world)
    {
        rate = speed;
        nextWorld = world;
        getImage().setTransparency(0);
    }
    /**
     * Act - do whatever the Screen wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        fade();
    }
    
    // Fade the screen in
    public void fade()
    {
        getImage().setTransparency(transparency);
        transparency += rate;
        if(transparency >= 255)
        {
            // Remove the screen when the screen becomes opaque
            getWorld().removeObject(this);
            setNextWorld();
        }
    }
    
    // Set the next world
    public void setNextWorld()
    {
        if(nextWorld == "HomeScreen")
        {
            Greenfoot.setWorld(new HomeScreen());
        }
        else if(nextWorld == "InviteScreen")
        {
            Greenfoot.setWorld(new InviteScreen());
        }
        else if(nextWorld == "HowToScreen")
        {
            Greenfoot.setWorld(new HowToScreen());
        }
        
        else if(nextWorld == "HouseScene")
        {
            Greenfoot.setWorld(new HouseScene());
        }
        else if(nextWorld == "Gps")
        {
            Greenfoot.setWorld(new Gps());
        }
        
        else if(nextWorld == "Street")
        {
            Greenfoot.setWorld(new Street());
        }
        else if(nextWorld == "Tunnel")
        {
            Greenfoot.setWorld(new Tunnel());
        }
        else if(nextWorld == "Party")
        {
            Greenfoot.setWorld(new Party());
        }
        else if(nextWorld == "FinalScreen")
        {
            Greenfoot.setWorld(new FinalScreen());
        }
    }
}
