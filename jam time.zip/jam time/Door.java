import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The door for raccoon's house
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends Actor
{   
    public Door()
    {
     
    }
    /**
     * Act - do whatever the Door wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkClicked();
        checkEPressed();
    }
    
    // Check whether the door was clicked
    public void checkClicked()
    {
        if(Greenfoot.mouseClicked(this))
        {
            Greenfoot.playSound("door.mp3");
            getWorld().addObject(new Screen(4, "Gps"), 350, 240);
            HouseScene hs = (HouseScene)getWorld();
            hs.stopSound();
        }
    }
    
    // Check whether 'e' was pressed and set the corresponding image
    public void checkEPressed()
    {
        if(Greenfoot.isKeyDown("e"))
        {
            setImage("door2.png");
        }
        else
        {
            setImage("door.png");
        }
    }
}
