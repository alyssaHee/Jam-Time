import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Pieces of the tunnel
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GroundTunnel extends Ground
{
    // Set the correct image for the ground length
    public GroundTunnel(int type)
    {
        setImage("ground" + type + ".png");
    }
    
    // The ground-ground of the tunnel
    public GroundTunnel()
    {
        setImage("groundfinal.png");
    }
}
