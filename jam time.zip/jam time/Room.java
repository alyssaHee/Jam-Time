import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Room of raccoon's house
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Room extends Actor
{
    // Create a GreenfootSound variable to hold onto sound
    GreenfootSound soundfx;
    
    // Counter that will only play soundfx once
    private int playOnce;
    
    // The location of the shelf in the room
    private int location;
    
    private int drink;
    public Room()
    {
        playOnce = 0;
        location = 150;
        soundfx = new GreenfootSound("select.mp3");
        soundfx.setVolume(40);
    }
    /**
     * Act - do whatever the Room wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        isScrolling();
        checkItemClicked();
    }
    
    // Determine whether or not to move the background depending on accessor from Raccoon
    public void isScrolling()
    {
        Raccoon r = (Raccoon)getOneIntersectingObject(Raccoon.class);
        if(r != null)
        {
            if(r.scrollBg() == 1)
            {
                scroll(true);
            }
            else if(r.scrollBg() == 2)
            {
                scroll(false);
            }
        }
    }
    
    // Scroll the room (move it left or right to give the illusion of movement)
    // The parameter determines whether to move left or right
    public void scroll(boolean moveRight)
    {
        if(moveRight && getX() != location)
        {
            move(-3);  
        }
        else if(!moveRight && getX() != location)
        {
            move(3);
        }
        // If the shelf is in the location of the raccoon's x position, stop movement
        else if(getX() == location)
        {
            setLocation(150, getY());
            // The if statement and the counter are to ensure that only one 
            // shelf-highlight is added
            playOnce ++;
            if(playOnce == 1)
            {
                soundfx.play();
                getWorld().addObject(new ShelfHighlight(), 374, 276);
                getWorld().addObject(new Text(2), 350, 452);
            }
        }
    }  
    
    // If the room is at the end, return 1 or 2. This allows the raccoon to change its speed based on where the room is
    public int isAtEnd()
    {
        if(getX() == 0)
        {
            return 1;
        }
        if(getX() == 699)
        {
            return 2;
        }
        else
        {
            return 0;
        }
    }
    
    // Selecting a drink from the shelf
    public void checkItemClicked()
    {
        // Access the drink selected from the ShelfHighlight class and set the corresponding image
        ShelfHighlight SH = (ShelfHighlight)getOneIntersectingObject(ShelfHighlight.class);
        if(SH != null)
        {
            if(SH.itemsPressed() == 1)
            {
                setImage("roomCan.png");
                location = -800;
                getWorld().removeObjects(getWorld().getObjects(ShelfHighlight.class));
            }
            
            else if(SH.itemsPressed() == 2)
            {
                setImage("roomPickle.png");
                location = -800;
                getWorld().removeObjects(getWorld().getObjects(ShelfHighlight.class));
            }
            
            else if(SH.itemsPressed() == 3)
            {
                setImage("roomRed.png");
                location = -800;
                getWorld().removeObjects(getWorld().getObjects(ShelfHighlight.class));
                drink = 1;
            }
            
            else if(SH.itemsPressed() == 4)
            {
                setImage("roomWater.png");
                location = -800;
                getWorld().removeObjects(getWorld().getObjects(ShelfHighlight.class));
            }
        }
    }
    
    public int typeDrink()
    {
        if(drink == 1)
        {
            return(1);
        }
        else 
        {
            return(0);
        }
    }
}

