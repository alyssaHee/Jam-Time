import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Next button on the invite screen
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NextButton extends Actor
{
    // Counter to ensure only one sound and one screen is added
    private int counter;
    public NextButton()
    {
        counter = 0;
    }
    /**
     * Act - do whatever the NextButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        pressed();
    }    
    
    // Check whether the button is pressed
    public void pressed()
    {
        if(Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("enter"))
        {
            counter ++;
            if(counter == 1)
            {
                Greenfoot.playSound("crumple.mp3");
                getWorld().addObject(new Screen(4, "HouseScene"), 350, 240);
                InviteScreen s = (InviteScreen)getWorld();
                s.stopMusic();
            }
        }
    }
}
