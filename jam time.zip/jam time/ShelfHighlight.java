import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Shows the names of the drinks to bring
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ShelfHighlight extends Actor
{
    // Hold onto the x and y position of the mouse
    private int mouseX;
    private int mouseY;

    /**
     * Act - do whatever the ShelfInfo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        showInfo();    
    }
    
    // If 'e' is held down
    public void showInfo()
    {
        if(Greenfoot.isKeyDown("e"))
        {
            setImage("shelf info.png");
        }
        else
        {
            setImage("highlightshelf.png");
        }
    }
    
    // If an item is clicked
    public int itemsPressed()
    {
        // Get the mouse information
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if(mouse!=null){
            mouseX = mouse.getX();
            mouseY = mouse.getY();
        }
        
        // if the mouse clicked the can
        if(Greenfoot.mousePressed(this) && (mouseX>336 && mouseX<351) && (mouseY>245 && mouseY<270))
        {
            Greenfoot.playSound("select1.mp3");
            return(1);
        }
        // if the mouse clicked the pickles
        else if(Greenfoot.mousePressed(this) && (mouseX>=405 && mouseX<425) && (mouseY>=240 && mouseY<=270))
        {
            Greenfoot.playSound("select1.mp3");
            return(2);
        }
        // if the mouse clicked the hyperquench
        else if(Greenfoot.mousePressed(this) && (mouseX>436 && mouseX<458) && (mouseY>241 && mouseY<271))
        {
            Greenfoot.playSound("select1.mp3");
            return(3);
        }
        // if the mouse clicked the water
        else if(Greenfoot.mousePressed(this) && (mouseX>=304 && mouseX<=324) && (mouseY>300 && mouseY<329))
        {
            Greenfoot.playSound("select1.mp3");
            return(4);
        }
        else
        {
            return(0);
        }
    }
}
