import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The tunnel world where raccoon tries not to disturb gopher
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tunnel extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class Tunnel.
     * 
     */
    public Tunnel()
    {    
        super(700, 480, 1); 
        backgroundMusic = new GreenfootSound("curious tiptoe.mp3");
        playMusic();
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(new GroundTunnel(1),766,110);
        addObject(new GroundTunnel(2),88,405);
        addObject(new GroundTunnel(6),182,110);
        addObject(new GroundTunnel(2),455,210);
        addObject(new GroundTunnel(4),20,210);
        addObject(new GroundTunnel(5),140,259);
        addObject(new GroundTunnel(5),100,350);
        addObject(new GroundTunnel(3),420,308);
        addObject(new GroundTunnel(), 350, 470);
        addObject(new Gopher(),560, 278);
        addObject(new GroundTunnel(5),632,254);
        addObject(new Potato(), 655, 283);
        addObject(new Potato(),40,183);
        addObject(new Potato(),33,444);
        addObject(new Potato(),566,184);
        addObject(new Potato(),500,283);
        addObject(new Exit(),600,431);
        addObject(new Raccoon(),60,0);
        addObject(new PotatoCounter(0),78,22);
        addObject(new Text(6), 350, 426);
    }
    
    // Play music
    public void playMusic()
    {
        backgroundMusic.setVolume(50);
        backgroundMusic.playLoop();
    }
    
    // Stop music
    public void stopMusic()
    {
        backgroundMusic.stop();
    }
    
    // Update the counter that keeps track of potatoes. (Mutator to be called by Raccoon)
    public void updatePotatoeCounter(int amount)
    {
        removeObjects(getObjects(PotatoCounter.class));
        addObject(new PotatoCounter(amount), 78, 22);
    }

}
