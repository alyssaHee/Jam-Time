import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Raccoon main character
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Raccoon extends Actor
{
    // Create an array to store animation when raccoon is idle
    private GreenfootImage[] idle;
    // Delays for the animation
    private int idleIndex;
    private int iterations;
    
    private GreenfootImage[] idleLeft;
    
    
    // Create an array to store animation when raccoon is moving right
    private GreenfootImage[] moveRight;
    private int moveRightIndex;
    
    // Create an array to store animation when raccoon is moving left
    private GreenfootImage[] moveLeft;
    private int moveLeftIndex;
    
    // Counters to delay animations and to ensure only one item is added once a condition is met
    private int moveIterations;
    private int addOneOnly;
    private int addOneOnly2;
    private int addOneOnly3;
    
    // Keep track of if the raccoon is moving and in which direction
    private boolean isMoving;
    private boolean movingRight;
    private boolean movingLeft;
    
    // Variables for falling and jumping
    private int speed;
    private int vSpeed;
    private int accel;
    
    // Keep track of if the raccoon is jumping
    private boolean isJumping;
    
    // The number of potatoes collected
    private static int POTATOES = 0;
    private static int potatoes1 = 0;
    // Type of drink selected
    private static int DRINK = 0;
    
    public Raccoon()
    {
        idle = new GreenfootImage[8];
        idleLeft = new GreenfootImage[8];
        moveRight = new GreenfootImage[8];
        moveLeft = new GreenfootImage[8];
        
        // Initialize variables
        idleIndex = 0;
        moveRightIndex = 0;
        moveLeftIndex = 0;
        iterations = 0;
        moveIterations = 0;
        isMoving = false;
        speed = 3;
        vSpeed = 5;
        accel = 1;
        isJumping = false;
        addOneOnly = 0;
        addOneOnly2 = 0;
        addOneOnly3 = 0;
        movingRight = true;
        
        // fill idle array with image objects
        for(int i = 0; i<idle.length; i++)
        {
            idle[i] = new GreenfootImage("pixil-frame" + i + ".png");
        }
        
        // fill second idle array
        for(int i = 0; i<idleLeft.length; i++)
        {
            idleLeft[i] = new GreenfootImage("idle" + i + ".png");
        }
        
        // fill moveRight array with image objects
        for(int i = 0; i<idle.length; i++)
        {
            moveRight[i] = new GreenfootImage("right-" + i + ".png");
        }
        
        // fill moveLeft array with image objects
        for(int i = 0; i<idle.length; i++)
        {
            moveLeft[i] = new GreenfootImage("left-" + i + ".png");
        }
    }
    
    /**
     * Act - do whatever the Raccoon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // The default is the raccoon isn't moving
        isMoving = false;
        
        movement();
        idle();
        onGround();
        setSpeed();
        checkFall();
        
        leaveTunnelWorld();
        collectPotato();
        touchGopher();
        leaveStreet();
        showInstructions();
        setFinalScreen();
        
        isTouchingPotatoBag();
    }
    
    // Main movement for raccoon
    public void movement()
    {
        // Moving right
        if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d"))
        {
            isMoving = true;
            movingRight = true;
            movingLeft = false;
            move(speed);
            moveIterations ++;
            if(moveIterations%4 == 0){
                moveRightIndex ++;
                moveIterations = 0;
            }
            
            if(moveRightIndex == moveRight.length)
            {
                moveRightIndex = 0;
            }
            setImage(moveRight[moveRightIndex]);
        }
        
        // Moving left
        else if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        {
            isMoving = true;
            movingRight = false;
            movingLeft = true;
            move(-speed);
            moveIterations ++;
            if(moveIterations%4 == 0){
                moveLeftIndex ++;
                moveIterations = 0;
            }
            if(moveLeftIndex == moveLeft.length)
            {
                moveLeftIndex = 0;
            }
            setImage(moveLeft[moveLeftIndex]);
        }
        
        // If the up key or w key is pressed, jump once
        if((Greenfoot.isKeyDown("w") || Greenfoot.isKeyDown("up")) && !isJumping)
        {
            isJumping = true;
            jump();
        }
    }
    
    // This method simulates gravity
    public void fall()
    {
        setLocation(getX(), getY()+vSpeed);
        vSpeed += accel;
    }
    
    // Set the vertical speed to -9 so the raccoon goes up and looks like a jump
    public void jump()
    {
        vSpeed = -9;
        fall();
    }
    
    // Checks if raccoon is on ground
    public boolean onGround()
    {
        Actor under = getOneObjectAtOffset(0, getImage().getHeight()/2, Ground.class);
        return under != null;
    }
    
    // Check whether the raccoon should fall or maintain position if it is on the ground
    public void checkFall()
    {
        if(onGround())
        {
            vSpeed = 0;
            accel = 0;
            isJumping = false;
        }
        else
        {
            accel = 1;
            fall();
        }
    }
    
    // Animations for if the raccoon is not moving
    public void idle()
    {
        if(!isMoving)
        {
            iterations ++;
            if(iterations % 5 == 0){
                idleIndex ++;
                iterations = 0;
            }
            
            if(idleIndex > 7)
            {
                idleIndex = 0;
            }
            if(movingRight)
            {
                setImage(idle[idleIndex]); 
            }
            if(!movingRight)
            {
                setImage(idleLeft[idleIndex]);
            }
        }
    }
    
    // Accessor for the room class to see whether the room should scroll or stay still
    public int scrollBg()
    {
        // Return 1 if the raccoon is in the middle of the screen and moving right
        if(isMoving && movingRight)
        {
            if(getX() >= 347&& getX() <= 353){
                return 1;
            }
            else{
                return 0;
            }
        }
        // Return 2 if the raccoon is in the middle of the screen and moving left
        else if(isMoving && movingLeft) 
        {
            if(getX() <= 351 && getX() >= 347)
            {
                getWorld().removeObjects(getWorld().getObjects(Door.class));
                return 2;
                
            }
            else{
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    
    
    // Access information from the room class to determine what speed the raccoon should go at
    // If the raccoon is in the middle of the room and moving right, the background will move while
    // raccoon stays still
    
    // This is to give the illusion that the raccoon is moving
    public void setSpeed()
    {
        Room r = (Room)getOneIntersectingObject(Room.class);
        if(r != null)
        {
            if(r.isAtEnd() == 1)
            {
                speed = 3;
                // If the raccoon is at the end of the room, a door will appear and it can be clicked on to exit
                // the world
                getWorld().addObject(new Door(), 621, 261);
            }
            else if(r.isAtEnd() == 2)
            {
                speed = 3;
            }
            else
            {
                speed = 0;
            }
        }
    }
    
    // Show certain instructions at certain points for raccoon in the how to play section
    public void showInstructions()
    {
        // Only continue if the world is in HowToScreen
        if(this.getWorld().getClass() == HowToScreen.class)
        {
            if(getX() > 440)
            {
                addOneOnly3 = 0;
                addOneOnly2 = 0;
                addOneOnly ++;
                if(addOneOnly == 1)
                {
                    getWorld().addObject(new Instructions(2), 350, 240);
                }
            }
            else if(getX() < 265)
            {
                addOneOnly = 0;
                addOneOnly3 = 0;
                addOneOnly2 ++;
                if(addOneOnly2 == 1)
                {
                    getWorld().addObject(new Instructions(1), 350, 240);
                }
            }
            else
            {
                addOneOnly = 0;
                addOneOnly2 = 0;
                addOneOnly3 ++;
                if(addOneOnly3 == 1)
                {
                    getWorld().addObject(new Instructions(0), 350, 240);
                }
            }
        }
    }
    
    // In the tunnel section of the game, if a potato is collected, add points to potato counter and remove potato
    public void collectPotato()
    {
        if(this.getWorld().getClass() == Tunnel.class)
        {
            if(isTouching(Potato.class))
            {
                POTATOES ++;
                Greenfoot.playSound("select1.mp3");
                removeTouching(Potato.class);
                if(POTATOES == 1)
                {
                    getWorld().removeObjects(getWorld().getObjects(Text.class));
                }
                Tunnel t = (Tunnel)getWorld();
                t.updatePotatoeCounter(POTATOES);
                potatoes1 = POTATOES;
            }
        }
    }
    
    // If the raccoon touches the Gopher
    public void touchGopher()
    {
        if(isTouching(Gopher.class))
        {
            Tunnel t = (Tunnel)getWorld();
            t.stopMusic();
            Greenfoot.playSound("roar.mp3");
            removeTouching(Gopher.class);
            getWorld().addObject(new Text(7), 346, 250);
            getWorld().addObject(new Screen(4, "Party"), 350, 240);
        }
    }
    
    // If the raccoon successfully makes it to the exit
    public void leaveTunnelWorld()
    {
        if(getX() > 600 && getY() > 430)
        {
            addOneOnly ++;
            if(addOneOnly == 1)
            {
                getWorld().addObject(new Screen(4, "Party"), 350, 240);
                Greenfoot.playSound("correct.mp3");
            }
            if(addOneOnly == 8)
            {
                Tunnel t = (Tunnel)getWorld();
                t.stopMusic();
            }
        }
    }
    
    // If the raccoon gets to the end of the street screen
    public void leaveStreet()
    {
        if(getX() > 600 && (getY() >= 305 && getY() <= 320))
        {
            addOneOnly ++;
            if(addOneOnly == 1)
            {
                Greenfoot.playSound("fall.mp3");
            }
            if(addOneOnly == 20)
            {
                getWorld().addObject(new Screen(4, "Tunnel"), 350, 240);
            }
            if(addOneOnly == 25)
            {
                Street s = (Street)getWorld();
                s.stopMusic();
            }
        }
    }
    
    // When the raccoon drops off potatoes
    public void isTouchingPotatoBag()
    {
        if(isTouching(PotatoDropOff.class))
        {
            int x = 0;
            if(Greenfoot.isKeyDown("s") || Greenfoot.isKeyDown("down"))
            {
                while(POTATOES > 0)
                {
                    getWorld().addObject(new Potato(), getX()+(x-4), getY());   
                    POTATOES --;
                    x += 20;
                }  
                addOneOnly ++;
                if(addOneOnly == 1)
                {
                    Greenfoot.playSound("select.mp3");
                }
                if(addOneOnly == 3)
                {
                    Greenfoot.playSound("trashcan.mp3");
                    getWorld().addObject(new Screen(3, "FinalScreen"), 350, 240);
                }
            }
        }
    }
    
    // Determine which screen to set for the final Screen depending on if the right drink was picked and amount of potatoes
    public void setFinalScreen()
    {
        Room r = (Room)getOneIntersectingObject(Room.class);
        if(r != null)
        {
            if(r.typeDrink() == 1)
            {
                DRINK = 1;
            }
            else
            {
                DRINK = 0;
            }
        }
        if(this.getWorld().getClass() == FinalScreen.class)
        {
            
            if(potatoes1 == 0)
            {
                if(DRINK == 1)
                {
                    getWorld().setBackground(new GreenfootImage("final6.png"));
                }
                else
                {
                    getWorld().setBackground(new GreenfootImage("final3.png"));
                }
            }
            if(potatoes1 == 5)
            {
                if(DRINK == 1)
                {
                    getWorld().setBackground(new GreenfootImage("final1.png"));
                }
                else
                {
                    getWorld().setBackground(new GreenfootImage("final4.png"));
                }
            }
            else
            {
                if(DRINK == 1)
                {
                    getWorld().setBackground(new GreenfootImage("final2.png"));
                }
                else
                {
                    getWorld().setBackground(new GreenfootImage("final5.png"));
                }
            }
        }
    }
}
