import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Top3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Top3 extends MapPieces
{
    /**
     * Act - do whatever the Top3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Methods from the MapPieces class
        mouseDragged();
        placePiece();
    }
    
    // Return whether the puzzle piece is in the right spot
    public boolean checkRightSpot()
    {
        if(getX() == 463 && getY() == 108)
        {
            return true;
        }
        else {
            return false;
        }
    }
}

