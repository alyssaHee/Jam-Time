import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HomeScreen extends World
{
    // Create variable to store the music file so we can stop it and set volume and such
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public HomeScreen()
    {    
        super(700, 480, 1); 
        
        backgroundMusic = new GreenfootSound("nighttime.mp3");
        playMusic();
        
        addObject(new Home(), 350, 240);
        addObject(new Dumpster(), 464, 346);
        addObject(new PlayButton(), 101, 223);
        addObject(new HowToButton(), 103, 310);
    }
    
    // Play music
    public void playMusic()
    {
        backgroundMusic.setVolume(60);
        backgroundMusic.playLoop();
    }
    
    // Stop music
    public void stopMusic()
    {
        backgroundMusic.stop();
    }
}
