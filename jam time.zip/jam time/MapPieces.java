import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MapPieces here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MapPieces extends Actor
{
    // If the mouse is dragged on a piece, make the piece follow the mouse cursor
    public void mouseDragged()
    {
        if(Greenfoot.mouseDragged(this))
        {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            setLocation(mouse.getX(), mouse.getY());
        }
    }
    
    // "Snap" the piece into a spot on the gps screen if it is in the range for the corresponding spot
    public void placePiece()
    {
        // Top1 spot
        if((getX() >= 169 && getX() <= 291) && (getY() >= 55 && getY() <= 164))
        {
            setLocation(225, 108);
        }
        // Top2 spot
        else if((getX() >= 291 && getX() <= 413) && (getY() >= 55 && getY() <= 164))
        {
            setLocation(346, 108);
        }
        // Top3 spot
        else if((getX() >= 413 && getX() <= 535) && (getY() >= 55 && getY() <= 164))
        {
            setLocation(463, 108);
        }   
        // Bottom1 spot
        else if((getX() >= 169 && getX() <= 291) && (getY() >= 164 && getY() <= 273))
        {
            setLocation(225, 215);
        }  
        // Bottom2 spot
        else if((getX() >= 291 && getX() <= 413) && (getY() >= 164 && getY() <= 273))
        {
            setLocation(344, 215);
        }  
        // Bottom3 spot
        else if((getX() >= 413 && getX() <= 535) && (getY() >= 164 && getY() <= 273))
        {
            setLocation(463, 215);
        } 
    }
}
