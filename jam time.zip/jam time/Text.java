import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Text here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Text extends Actor
{
    public Text()
    {
       
    }
    
    // Overloading constructor to change the image of the text
    public Text(int image)
    {
        setImage("text"+image+".png");      
    }
    /**
     * Act - do whatever the Text wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setTextRoom();
    }    
    
    // Depending on where the room is, change the text shown
    public void setTextRoom()
    {
        if(this.getWorld().getClass() == HouseScene.class)
        {
            // Use an accessor to determine what image is used
            Room r = (Room)getOneIntersectingObject(Room.class);
            if(r != null)
            {
                if(r.isAtEnd() == 1)
                {                
                    setImage("text3.png");
                }
                else if(r.isAtEnd() == 2)
                {
                    setImage("text1.png");
                }
            }
        }
    }
}
