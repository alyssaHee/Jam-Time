import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the last screen where we find out if you get into The Spud
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Party extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class Party.
     * 
     */
    public Party()
    {    
        super(700, 480, 1);
        prepare();
        setPaintOrder(Screen.class, Ground.class, Raccoon.class, PotatoDropOff.class, Text.class);
        playMusic();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(new PotatoDropOff(),343,392);
        addObject(new Ground(), 350, 470);
        addObject(new Raccoon(), 0, 390);
        addObject(new Text(5), 350, 450);
    }
    // Play music
    public void playMusic()
    {
        backgroundMusic = new GreenfootSound("nighttime.mp3");
        backgroundMusic.setVolume(65);
        backgroundMusic.playLoop();
    }
    
    // Stop music
    public void stopSound()
    {
        backgroundMusic.stop();
    }
}
