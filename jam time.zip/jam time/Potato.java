import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A little potato
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Potato extends Actor
{
    private int iterations;
    public Potato()
    {
        iterations = 0;
    }
    /**
     * Act - do whatever the Potato wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        disappear();
    }
    
    // When the potatoes are collected at the dumpster scene 
    public void disappear()
    {
        if(this.getWorld().getClass() == Party.class)
        {
            iterations ++;
            setLocation(getX(), getY() - 1);
            if(iterations == 30 && isTouching(PotatoDropOff.class))
            {
                Party p = (Party)getWorld();
                p.stopSound();
            }
            if(iterations == 35)
            {
                getWorld().removeObject(this);
            }
        }
    }
    

}
