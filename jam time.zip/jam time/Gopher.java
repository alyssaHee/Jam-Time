import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gopher here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gopher extends Actor
{
    // Array to hold onto images in gopher animation
    private GreenfootImage[] animate;
    
    private int currIndex;
    private int iterations;
    public Gopher()
    {
        animate = new GreenfootImage[2];
        iterations = 0;
        // Fill the array
        animate[0] = new GreenfootImage("gopher1.png");
        animate[1] = new GreenfootImage("gopher2.png");
    }
    /**
     * Act - do whatever the Gopher wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        animate();
    }
    
    // Animate the gopher
    public void animate()
    {
        iterations++;
        if(iterations%30 == 0){
            currIndex ++;
            iterations = 0;
        }
        
        if(currIndex > 1)
        {
            currIndex = 0;
        }
        setImage(animate[currIndex]);
    }
}
