import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * How to play Screen 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HowToScreen extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class HowToScreen.
     * 
     */
    public HowToScreen()
    {    
        super(700, 480, 1); 

        backgroundMusic = new GreenfootSound("hm.mp3");
        playMusic();
    
        prepare();
        setPaintOrder(Screen.class, Ground.class, Raccoon.class, BackButton.class, Quench.class, Flower.class, Instructions.class);
    }
    
    // Play music
    public void playMusic()
    {
        backgroundMusic.setVolume(40);
        backgroundMusic.playLoop();
    }

    // Stop music
    public void stopMusic()
    {
        backgroundMusic.stop();
    }
        
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(new Instructions(0), 350, 240);
        addObject(new BackButton(), 350, 420);
        addObject(new Ground(), 350, 240);
        addObject(new Flower(), 570, 124);
        addObject(new Quench(),116,154);
        addObject(new Raccoon(), 350, 0);
    }
    
}
