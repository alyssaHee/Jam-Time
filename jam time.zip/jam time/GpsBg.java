import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Sets the background of the gps scene and checks whether the puzzle is correct
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GpsBg extends Actor
{
    // Variables to hold onto whether or not a piece is in the right spot
    private int b1;
    private int b2;
    private int b3;
    private int t1;
    private int t2;
    private int t3;
    
    // Add only one object if a condition is met and delay the time it takes to stop the music
    private int delay;
    public GpsBg()
    {
        delay = 0;
    }
    /**
     * Act - do whatever the GpsBg wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */  
    public void act()
    {
        checkCorrect();
    }
    
    // Check if the pieces are in the right spot by accessing position in the respective classes
    public void checkCorrect()
    {
        Bottom1 B1 = (Bottom1)getOneIntersectingObject(Bottom1.class);
        if(B1 != null)
        {
            if(B1.checkRightSpot())
            {
                // If the piece is in the right spot, set the corresponding variable to 1
                b1 = 1;
            }
            else
            {
                b1 = 0;
            }
        }
        
        Bottom2 B2 = (Bottom2)getOneIntersectingObject(Bottom2.class);
        if(B2 != null)
        {
            if(B2.checkRightSpot())
            {
                b2 = 1;
            }
            else
            {
                b2 = 0;
            }
        }
        
        Bottom3 B3 = (Bottom3)getOneIntersectingObject(Bottom3.class);
        if(B3 != null)
        {
            if(B3.checkRightSpot())
            {
                b3 = 1;
            }
            else
            {
                b3 = 0;
            }
        }
        
        Top1 T1 = (Top1)getOneIntersectingObject(Top1.class);
        if(T1 != null)
        {
            if(T1.checkRightSpot())
            {
                t1 = 1;
            }
            else
            {
                t1 = 0;
            }
        }
        
        Top2 T2 = (Top2)getOneIntersectingObject(Top2.class);
        if(T2 != null)
        {
            if(T2.checkRightSpot())
            {
                t2 = 1;
            }
            else
            {
                t2 = 0;
            }
        }
        
        Top3 T3 = (Top3)getOneIntersectingObject(Top3.class);
        if(T3 != null)
        {
            if(T3.checkRightSpot())
            {
                t3 = 1;
            }
            else
            {
                t3 = 0;
            }
        }
        
        // If all of the corresponding variables add up to 6, all the pieces are in the correct spot
        if(t1+t2+t3+b1+b2+b3 == 6)
        {
            setImage("gps21.png");
            delay ++;
            if(delay == 1)
            {
                // Cast a pointer to the Gps world so we can call stopMusic();
                Gps gps = (Gps)getWorld();
                gps.stopMusic();
            }
            if(delay == 2)
            {
                Greenfoot.playSound("correct.mp3");
            }
            if(delay == 60)
            {
                getWorld().addObject(new Screen(3, "Street"), 350, 240);
            }
        }
    }
}
