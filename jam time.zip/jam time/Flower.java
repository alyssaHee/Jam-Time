import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The flower in the how to play screen
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Flower extends Actor
{
    /**
     * Act - do whatever the Flower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        showInfo();    
    }
    
    // If e is pressed, show the text
    public void showInfo()
    {
        if(Greenfoot.isKeyDown("e"))
        {
            setImage("flowerHighlight.png");
        }
        else
        {
            setImage("flower.png");
        }
    }
}
