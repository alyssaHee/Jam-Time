import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Top2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Top2 extends MapPieces
{
    /**
     * Act - do whatever the Top2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Methods from MapPieces parent class
        mouseDragged();
        placePiece();
    }
    
    // Return whether the puzzle piece is in the right spot
    public boolean checkRightSpot()
    {
        if(getX() == 346 && getY() == 108)
        {
            return true;
        }
        else {
            return false;
        }
    }
}
