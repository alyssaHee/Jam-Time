import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The house world where the raccoon gets a drink and heads out ot party
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HouseScene extends World
{
    // Variable to hold onto music file so it can be manipulated using GreenfootSound methods
    private GreenfootSound music;
    /**
     * Constructor for objects of class LevelOne.
     * 
     */
    public HouseScene()
    {    
        super(700, 480, 1); 
        
        music = new GreenfootSound("elevator.mp3");
        playMusic();
        
        addObject(new Room(), 700, 240);
        addObject(new Raccoon(), 63, 350);
        addObject(new Text(), 350, 452);
        addObject(new Ground(), 350, 430);
        
        setPaintOrder(Screen.class, Raccoon.class, Ground.class, ShelfHighlight.class, Door.class, Text.class, Room.class);
    }
    
    // play the music
    public void playMusic()
    {
        music.setVolume(40);
        music.playLoop();
    }
    
    // Stop the music
    public void stopSound()
    {
        music.stop();
    }
}
