import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Sets the counter for the potatoes collected
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PotatoCounter extends Actor
{
    public PotatoCounter(int amount)
    {
        if(amount == 6)
        {
            amount = 5;
        }
        setImage(amount+"potato.png");
    }
}
