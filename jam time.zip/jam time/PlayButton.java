import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The button that starts the game
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlayButton extends Actor
{
    /**
     * Act - do whatever the PlayButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        pressed();
    }
    
    // Check if the play button is pressed
    public void pressed()
    {
        if(Greenfoot.mouseClicked(this))
        {
            Greenfoot.playSound("click2.mp3");
            getWorld().addObject(new Screen(4, "InviteScreen"), 350, 240);
            HomeScreen h = (HomeScreen)getWorld();
            h.stopMusic();
        }
    }
}
