import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * An exit sign
 * 
 * Could've just put it as part of groundfinal image and saved a class, but then the sign would be counted as ground
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Exit extends Actor
{

}
