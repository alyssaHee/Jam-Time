import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinalScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinalScreen extends World
{
    private GreenfootSound backgroundMusic;
    /**
     * Constructor for objects of class FinalScreen.
     * 
     */
    public FinalScreen()
    {    
        super(700, 480, 1); 
        playMusic();
        addObject(new Ground(), 350, 480);
        addObject(new Raccoon(), 365, 420);
        setPaintOrder(Ground.class, Raccoon.class);
    }

    // Play music
    public void playMusic()
    {
        backgroundMusic = new GreenfootSound("music.mp3");
        backgroundMusic.setVolume(50);
        backgroundMusic.play();
    }
}
