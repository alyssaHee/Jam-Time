import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The back button for the how to play screen
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BackButton extends Actor
{
    // Ensure that only one item/sound is added/played when a condition is met
    private int addOneOnly;
    public BackButton()
    {
        addOneOnly = 0;
    }
    /**
     * Act - do whatever the BackButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
        public void act() 
    {
        pressed();
    }    
    
    // Check if the button was pressed
    public void pressed()
    {
        if(Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("enter"))
        {
            addOneOnly ++;
            if(addOneOnly == 1)
            {
                Greenfoot.playSound("click.mp3");
                getWorld().addObject(new Screen(4, "HomeScreen"), 350, 240);
                HowToScreen hts = (HowToScreen)getWorld();
                hts.stopMusic();
            }
        }
    }
}
